package c05.decorator.title;

/**
 * 冒險者介面(Component)-規範冒險者應該有的功能
 */
public interface Adventurer {	
	/**
	 * 攻擊
	 */
	 void attack();
}
