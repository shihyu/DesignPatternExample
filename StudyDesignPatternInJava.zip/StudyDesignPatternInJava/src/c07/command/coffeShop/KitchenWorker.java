package c07.command.coffeShop;
/**
 * 廚房人員(Receiver)
 */
public interface KitchenWorker {
	/**
	 * 完成訂單
	 */
	void finishOrder();
}
