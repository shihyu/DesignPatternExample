package b.solid.ISP;

// 實作此介面的車可以在馬路上行駛
public interface 可以上路的車 {
	void 路上跑();
}
