package b.solid.ISP;

public class 樂高車  extends 阿文的車{
	public void 炫富(){
		System.out.println("我是一台很酷很酷的車，1:1的樂高模型車，看過沒");
	}
	public void 佔車位(){
		System.out.println("說到佔車位，我是第二，誰敢說第一");
	}
}
