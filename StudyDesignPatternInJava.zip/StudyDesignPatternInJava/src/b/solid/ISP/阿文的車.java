package b.solid.ISP;

public abstract class 阿文的車 {
	public void 炫富(){
		System.out.println("我是一台很酷很酷的車，我好棒");
	}
	public void 佔車位(){
		System.out.println("車庫不是買來好看的，一定要放一台車");
	}
}
