package b.solid.LSP;

public class 超級跑車  implements 車 {
	public void 路上跑(){
		System.out.println("我身輕如燕，跑起來像飛一樣");
	}
}
