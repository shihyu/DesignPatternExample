package c14.iterator.simpleList;

/**
 * 自己做一個簡單的list
 */
public interface SimpleListInterface {
	
	// simpleList 要有增加元素的方法
	public void add(String string);
}
