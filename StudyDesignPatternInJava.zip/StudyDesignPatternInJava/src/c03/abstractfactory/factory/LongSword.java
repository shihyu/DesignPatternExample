package c03.abstractfactory.factory;
/**
 * 長劍(ConcreteProduct)-鬥士武器
 */
public class LongSword extends Weapon {

}
