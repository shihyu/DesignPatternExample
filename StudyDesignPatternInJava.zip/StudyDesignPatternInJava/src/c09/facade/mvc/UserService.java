package c09.facade.mvc;

/**
 * 處理會員註冊的controller
 */
public class UserService {
	
	public String register(Object object){
		String result = "註冊成功頁面";
		
		return result;
	}
	
}
