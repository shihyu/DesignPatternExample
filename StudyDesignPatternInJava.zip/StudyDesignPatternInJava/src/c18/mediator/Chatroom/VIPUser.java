package c18.mediator.Chatroom;
/**
 * 可以發送訊息的類別(ConcreteColleague)
 */
public class VIPUser extends Messager{
	public VIPUser(String name) {
		super(name);
	}	
}
