package c21.bridge.mail;

public abstract class Mail {
	// 平信，掛號信，雙掛號信等
	abstract void resgiterState();
}
