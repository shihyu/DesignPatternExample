package c21.bridge.descript.a;

public class 限時信件 extends 信件{

}
