package c21.bridge.descript.a;

public class 普通信件 extends 信件{

}
