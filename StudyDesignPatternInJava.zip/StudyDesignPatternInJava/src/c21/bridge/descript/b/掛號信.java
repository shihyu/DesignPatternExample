package c21.bridge.descript.b;

public class 掛號信 extends 信件{
	@Override
	void resgiterState() {
		System.out.println("這是一封掛號信，收件人必需簽名  ");
	}
}
