package c01.simpleFactory.village;

public interface Product {

}
