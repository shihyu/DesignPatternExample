package c01.simpleFactory.village;

public class ProductA implements Product {

}
