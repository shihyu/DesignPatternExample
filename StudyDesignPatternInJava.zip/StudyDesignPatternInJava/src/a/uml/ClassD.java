package a.uml;

public class ClassD {
	public ClassA a;
}
