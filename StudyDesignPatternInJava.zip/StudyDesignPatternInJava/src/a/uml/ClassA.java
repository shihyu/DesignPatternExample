package a.uml;

import java.util.List;

public class ClassA {
	public ClassD d;
	public ClassB b;
	public List<ClassC> cList;
}
