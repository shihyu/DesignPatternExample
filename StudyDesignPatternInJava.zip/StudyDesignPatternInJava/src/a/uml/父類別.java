package a.uml;

public class 父類別 implements 介面{

}
