package a.uml;

public class ClassB {

}
