package a.uml;

public interface 介面 {

}
