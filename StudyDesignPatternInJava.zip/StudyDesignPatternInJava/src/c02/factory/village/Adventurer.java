package c02.factory.village;
/**
 * 冒險者
 * @author Yan
 */
public interface Adventurer {
	/**
	 * 告訴別人你是哪種冒險者
	 */
	String getType();
}
