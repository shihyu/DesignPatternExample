package c10.template.adventurer;
/**
 * 冒險者-鋼彈Justice
 */
public class GundamJustice extends Adventurer {
	public GundamJustice(){
		super.type = "Gundam-Justice";
		super.level = 100;	//鋼彈等級很高的
	}
}
